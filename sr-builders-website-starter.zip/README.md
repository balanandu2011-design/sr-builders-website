# SR Builders & Developers — website starter

This is a static, responsive HTML/CSS website starter for the two ventures:
- SR Colony — ₹12,000 per sq. yd.
- Victory — ₹12,500 per sq. yd.

## Preview locally
Open `index.html` in a browser.

## Deploy to Vercel
1. Create a GitHub repository and upload the contents of this folder.
2. In Vercel, choose **Add New → Project** and import that repository.
3. Framework preset: **Other**. Build command: leave blank. Output directory: `.`.
4. Deploy.

The site uses the buyer enquiry form supplied by the owner and includes click-to-call/WhatsApp links. Review all marketing claims, prices, approvals, and location details before publishing.
